-- MySQL dump 10.19  Distrib 10.3.31-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: chat
-- ------------------------------------------------------
-- Server version	10.3.31-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chat_message`
--

DROP TABLE IF EXISTS `chat_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message` text DEFAULT NULL,
  `sendTimeAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_id` varchar(255) DEFAULT NULL,
  `room_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `chat_message_index` (`room_id`),
  KEY `chat_message_index_userId` (`user_id`),
  KEY `chat_message_read_index_userId` (`user_id`),
  KEY `index_userId` (`user_id`),
  CONSTRAINT `FKfvbc4wvhk51y0qtnjrbminxfu` FOREIGN KEY (`room_id`) REFERENCES `chat_room` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=319 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_message`
--

LOCK TABLES `chat_message` WRITE;
/*!40000 ALTER TABLE `chat_message` DISABLE KEYS */;
INSERT INTO `chat_message` VALUES (201,'안녕하세요!','2021-08-19 04:32:06','1842455905',76),(202,'안녕하세요!','2021-08-19 04:32:12','1853181931',76),(203,'상담신청서 잘 받았습니다!','2021-08-19 04:32:18','1853181931',76),(204,'감사합니다 ㅎㅎ','2021-08-19 04:32:21','1842455905',76),(205,'혹시 언제 상담 원하시나요?','2021-08-19 04:32:27','1853181931',76),(206,'음 오늘 오후 2시쯤 괜찮으실까요?','2021-08-19 04:32:39','1842455905',76),(207,'가능합니다! 그럼 2시에 뵐게요!','2021-08-19 04:32:47','1853181931',76),(208,'넵넵! 이따 봬요~~','2021-08-19 04:32:52','1842455905',76),(242,'안녕하세요 밤이주인님','2021-08-19 07:26:46','1855869078',79),(243,'저기요..','2021-08-19 07:28:08','1855869078',79),(247,'저기요...','2021-08-19 07:29:18','1855869078',79),(248,'코','2021-08-19 11:10:05','1842456115',150),(249,'코코네넨','2021-08-19 11:10:17','1842456115',151),(250,'코코','2021-08-19 11:10:18','1842456115',151),(251,'코오','2021-08-19 11:10:29','1842456115',150),(252,'공고보고 연락드립니다!','2021-08-19 12:46:18','1855966971',153),(253,'오 네 안녕하세요!','2021-08-19 12:46:23','1853181931',153),(254,'제가 모마빌딩앞에서 그레이푸들을 주웠는데','2021-08-19 12:46:28','1855966971',153),(255,'헉 넵넵','2021-08-19 12:46:33','1853181931',153),(256,'실종공고 아이와 비슷해보여서요!','2021-08-19 12:46:33','1855966971',153),(257,'악 잠시만요!','2021-08-19 12:46:40','1853181931',153),(258,'혹시 제 공고 확인 가능하신가요?','2021-08-19 12:46:41','1855966971',153),(259,'넵! 확인해보겠습니다!','2021-08-19 12:46:48','1853181931',153),(260,'그레이푸들이고 여자에요!','2021-08-19 12:47:02','1855966971',153),(261,'ㅜㅜㅜ 제 강아지 맞아요ㅜㅜㅜㅜㅜㅜ','2021-08-19 12:47:03','1853181931',153),(262,'헉 다행이네요','2021-08-19 12:47:07','1855966971',153),(263,'혹시... 오늘 호수공원에서 저녁 8시쯤 만나실 수 있을까요?','2021-08-19 12:47:21','1853181931',153),(264,'넵 가능합니다!','2021-08-19 12:47:25','1855966971',153),(265,'그때 뵐게요!!','2021-08-19 12:47:27','1855966971',153),(266,'감사합니다!!!!','2021-08-19 12:47:29','1853181931',153),(267,'안녕하세요 게시글 보고 연락드립니다. 제가 찾는 강아지와\n 너무 흡사한 것 같아서요,,,','2021-08-19 14:27:56','1855869078',158),(268,'강아지를 발견하신 날짜와 시간을 알려주실 수 있나요??','2021-08-19 14:29:11','1855869078',158),(269,'그리고 \n가능하다면 오후에 화상상담을 통해 강아지 모습을 한번 확인해 볼 수 있을까요??ㅠㅠㅠ','2021-08-19 14:29:36','1855869078',158),(270,'답자아아아아앙~~~~~','2021-08-19 14:31:02','1855966971',155),(271,'입니다앙어ㅏㅇ아ㅏ아앙','2021-08-19 14:31:05','1855966971',155),(272,'앗 가능합니다!! 오후 2시 괜찮으세요?','2021-08-19 14:33:18','1855966971',158),(273,'모마빌딩 앞에서 오전 8시경에 발견했습니다!!','2021-08-19 14:34:33','1855966971',158),(274,'현재 동동분식에서 보호중이에요','2021-08-19 14:34:38','1855966971',158),(275,'헉 제가 동동분식이랑 20분거리에서 잃어버렸는데...맞는 것 같아요ㅠㅠㅠ!','2021-08-19 14:36:44','1855869078',158),(276,'이따 오후 2시에 그럼 화상상담으로 한번 확인 \n부탁드리겠습니다 감사합니다ㅠㅠ','2021-08-19 14:37:03','1855869078',158),(303,'네넨\n네네ㅔ','2021-08-20 01:11:54','1842456115',150),(304,'슬적','2021-08-20 01:12:27','1842456115',79),(305,'슬적','2021-08-20 01:12:29','1842456115',79);
/*!40000 ALTER TABLE `chat_message` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20 11:01:49
