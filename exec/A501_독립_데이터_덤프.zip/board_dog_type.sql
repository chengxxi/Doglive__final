-- MySQL dump 10.19  Distrib 10.3.31-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: board
-- ------------------------------------------------------
-- Server version	10.3.31-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dog_type`
--

DROP TABLE IF EXISTS `dog_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dog_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dog_type`
--

LOCK TABLES `dog_type` WRITE;
/*!40000 ALTER TABLE `dog_type` DISABLE KEYS */;
INSERT INTO `dog_type` VALUES (1,'믹스견'),(2,'셰퍼드'),(3,'도베르만'),(4,'골든리트리버'),(5,'웰시코기'),(6,'사모예드'),(7,'스피츠'),(8,'슈나우저'),(9,'비숑'),(10,'시츄'),(11,'치와와'),(12,'진도견'),(13,'말티즈'),(14,'파피용'),(15,'포메라니안'),(16,'요크셔테리어'),(17,'에어데일테리어'),(18,'스코티시테리어'),(19,'비글'),(20,'닥스훈트'),(21,'아프간하운드'),(22,'그레이하운드'),(23,'바셋하운드'),(24,'코커스페니얼'),(25,'포인터'),(26,'세터'),(27,'비즐라'),(28,'시베리안허스키'),(29,'알래스칸말라뮤트'),(30,'로트와일러'),(31,'보더콜리'),(32,'달마시안'),(33,'차우차우'),(34,'삽살개'),(35,'스탠다드푸들'),(36,'래브라도리트리버'),(37,'케인코르소'),(38,'버니스마운틴도그'),(39,'올드잉글리쉬쉽도그'),(40,'그레이트피레니즈'),(41,'잉글리시불독'),(42,'아메리칸불독'),(43,'불테리어'),(44,'보스턴테리어'),(46,'라이카'),(47,'풍산개'),(48,'샤페이'),(49,'페키니즈'),(50,'시바견'),(51,'핏불테리어'),(52,'폭스테리어'),(54,'프랜치불독'),(55,'실키테리어'),(56,'복서'),(57,'폼피츠'),(58,'퍼그'),(59,'미니어처핀셔'),(60,'아키타'),(63,'셔틀랜드쉽독'),(64,'푸들');
/*!40000 ALTER TABLE `dog_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20 11:01:18
