-- MySQL dump 10.19  Distrib 10.3.31-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: community
-- ------------------------------------------------------
-- Server version	10.3.31-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `community`
--

DROP TABLE IF EXISTS `community`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `community` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` text DEFAULT NULL,
  `title` varchar(30) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `category` varchar(10) DEFAULT NULL,
  `regDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community`
--

LOCK TABLES `community` WRITE;
/*!40000 ALTER TABLE `community` DISABLE KEYS */;
INSERT INTO `community` VALUES (52,'공부를 오랜만에 하니까 힘드네요','히히히','1842510887','자유게시판','2021-08-16 06:03:49','2021-08-16 06:03:49'),(53,'오늘 날씨가 너무 좋아서 10년만에 원피스를 입어보았는데 어떤가요?','오늘 날씨가 너무 좋아요!','1842510887','자유게시판','2021-08-16 07:16:51','2021-08-16 07:16:52'),(58,'다들 집에 강쥐 있으세요 ?ㅋ \n없으시면 우리집 뭉치 보고 가세요\n있으시면 다들 공유좀 해주세요 정신적으로 고통받아서 강쥐치료좀 해야겠어요 ','너네집에강쥐있냐..? ','1842379765','입양일기','2021-08-17 05:47:03','2021-08-17 05:47:03'),(59,'프로도는 나한테 관심이 없다......','프로도 임보일기 3일차','1842634691','임보일기','2021-08-17 08:47:18','2021-08-17 08:47:18'),(60,'독립 통해서 입양했어요 잘생긴 울 아덜램~~~~^^*','잘생긴 울애긔 라이키','1842634691','입양일기','2021-08-18 02:14:37','2021-08-18 02:14:37'),(61,'또?물보라를?일으켜?? ..다..?..다..?..다..?..다...?...다다다..?...다다다...??또?물보라를?일으켜?? ..다..?..다..?..다..?..다...?...다다다..?...다다다...?? 또?물보라를?일으켜?? ..다..?..다..?..다..?..다...?...다다다..?...다다','구름이랑 여름휴가 ?','1842634691','입양일기','2021-08-18 02:54:34','2021-08-18 02:54:34'),(62,'신난 호두랑 쫑이 ?\n\n#넘귀여워 #행복해','행복한 저희집 강쥐들 보고가세요~~~@@!','1842456115','자유게시판','2021-08-18 06:15:25','2021-08-18 06:15:25'),(63,'아니 글쎄 제가 씻고 온 사이에 셀카를 찍어놨더라니깐요','우리 진수는 천재예요','1842379765','임보일기','2021-08-18 09:02:11','2021-08-18 09:02:11'),(65,'남편이 \'독립\'에서 깜짝 선물로 입양해온 아이입니다. 너무 귀엽죠~~^^\n그런데 남편이 강아지털에 알러지가 있다는 걸 알게됐어요~~~ㅠ..ㅠ\n어쩔 수 없지만 새로운 집으로 보내야 될 처지에 놓여서 그런데 도와주실 분 있나요?\n이름은 최용건이구요, 나이는 61살 입니다. 집안일도 잘 도와주고 차도 좋은 거 타고 다니고 기념일도 잘 챙긴답니다^^@@@','이 아이는 리리입니다.','1842634691','입양일기','2021-08-19 00:46:00','2021-08-19 00:46:00'),(66,'대형견이라 사람들이 무서워해서 근처 공원에서 잠시 풀어주는 것도 못했는데\n사람없는 곳으로 와서 풀어주니 너무 행복해하네요?\n\n자주 놀러가자!','날이 좋아서 조금 먼 공원으로 나왔어요~','1842456115','임보일기','2021-08-19 01:23:49','2021-08-19 01:23:49'),(74,'임보한지 어느덧 일주일째\n두마리나 임보중이에요^^\n어찌나 사이가 좋던지 잘때도 꼬옥 껴안고 자더라니깐요 ','저희집 강쥐들','1842510887','임보일기','2021-08-19 07:13:15','2021-08-19 07:13:15'),(75,'진수 근황 많이 궁금해하셧죠 ㅋ\n아니글쎄 제가 밥먹고온사이에 또 셀카를 찍어놨더라니깐요','진수 뉴사 업뎃 ㅋ ','1855869078','입양일기','2021-08-19 10:00:36','2021-08-19 10:00:36'),(76,'브이이~ ✌ \n제 셀. 카 어떤 가 요 ? . . . ?\n\n독립 최고예요! 독립 덕분에 평생 가족을 만났지뭐예요 ~~~','셀카 올려도 돼요?','1842379765','임보일기','2021-08-19 10:49:44','2021-08-19 10:49:44'),(79,'하이 독립 마스코트 리부입니다~~~?','안녕하세요~리부에요~~?','1855966971','자유게시판','2021-08-19 12:53:01','2021-08-19 12:53:01'),(84,'독립에서 데려온 꼬미 입니다! 너무 귀엽죠?','귀여운 울 강쥐','1855869078','입양일기','2021-08-19 13:58:04','2021-08-19 13:58:04'),(86,'너무 너무 귀여워 ?','호두는 귀여워','1842456115','입양일기','2021-08-20 01:45:02','2021-08-20 01:45:02');
/*!40000 ALTER TABLE `community` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20 11:01:35
