-- MySQL dump 10.19  Distrib 10.3.31-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: community
-- ------------------------------------------------------
-- Server version	10.3.31-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `community_image`
--

DROP TABLE IF EXISTS `community_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `community_image` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file_path` varchar(255) DEFAULT NULL,
  `community_id` bigint(20) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6skixbvtayd4synfpjijy5bn0` (`community_id`),
  CONSTRAINT `FK6skixbvtayd4synfpjijy5bn0` FOREIGN KEY (`community_id`) REFERENCES `community` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_image`
--

LOCK TABLES `community_image` WRITE;
/*!40000 ALTER TABLE `community_image` DISABLE KEYS */;
INSERT INTO `community_image` VALUES (6,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20211516161513-KakaoTalk_20210815_020334446.j',52,'static/20211516161513-KakaoTalk_20210815_020334446.j'),(7,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20211616161652-루피.jfif',53,'static/20211616161652-루피.jfif'),(8,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20211816161818-루피윙크.jpg',53,'static/20211816161818-루피윙크.jpg'),(14,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20214717144703-puppy-3979350_640.jpg',58,'static/20214717144703-puppy-3979350_640.jpg'),(15,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20214717174718-dog.jpeg',59,'static/20214717174718-dog.jpeg'),(16,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20211418111437-라이카.jpg',60,'static/20211418111437-라이카.jpg'),(17,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20215418115434-andre-tan-70EmnzDQxpY-unsplash',61,'static/20215418115434-andre-tan-70EmnzDQxpY-unsplash'),(18,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20215418115435-andre-tan-IcsEQrEPubU-unsplash',61,'static/20215418115435-andre-tan-IcsEQrEPubU-unsplash'),(20,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20211518151525-KakaoTalk_20210818_151420462.j',62,'static/20211518151525-KakaoTalk_20210818_151420462.j'),(21,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20211518151547-KakaoTalk_20210818_151346470.j',62,'static/20211518151547-KakaoTalk_20210818_151346470.j'),(23,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20210218180218-337b733b1686e3ff5a5ef3326f31c8',63,'static/20210218180218-337b733b1686e3ff5a5ef3326f31c8'),(25,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20214619094600-oscar-sutton-uPT0hIe-zxI-unspl',65,'static/20214619094600-oscar-sutton-uPT0hIe-zxI-unspl'),(26,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20212319102349-nataliia-kvitovska-t64RjBExKCQ',66,'static/20212319102349-nataliia-kvitovska-t64RjBExKCQ'),(35,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20211319161315-e96e8642bc43eb656fcba7651c410c',74,'static/20211319161315-e96e8642bc43eb656fcba7651c410c'),(36,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20210019190036-184dab374e77d335814217f964082c',75,'static/20210019190036-184dab374e77d335814217f964082c'),(37,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20214919194944-c9f0154f5032a9f3ff79f036e34cc5',76,'static/20214919194944-c9f0154f5032a9f3ff79f036e34cc5'),(41,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20215319215301-KakaoTalk_20210819_141803280.p',79,'static/20215319215301-KakaoTalk_20210819_141803280.p'),(42,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20215319215301-KakaoTalk_20210819_141811494.p',79,'static/20215319215301-KakaoTalk_20210819_141811494.p'),(47,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20215819225804-강쥐.jpeg',84,'static/20215819225804-강쥐.jpeg'),(49,'https://d2ud6j7vlf3xy9.cloudfront.net/static/20214520104502-KakaoTalk_20210820_104344992.j',86,'static/20214520104502-KakaoTalk_20210820_104344992.j');
/*!40000 ALTER TABLE `community_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20 11:01:40
