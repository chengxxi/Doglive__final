-- MySQL dump 10.19  Distrib 10.3.31-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: auth
-- ------------------------------------------------------
-- Server version	10.3.31-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_profile`
--

DROP TABLE IF EXISTS `user_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `phone_number` varchar(13) DEFAULT NULL,
  `profile_image_url` varchar(255) DEFAULT NULL,
  `user_id` varchar(13) DEFAULT NULL,
  `birth` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6kwj5lk78pnhwor4pgosvb51r` (`user_id`),
  CONSTRAINT `FK6kwj5lk78pnhwor4pgosvb51r` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profile`
--

LOCK TABLES `user_profile` WRITE;
/*!40000 ALTER TABLE `user_profile` DISABLE KEYS */;
INSERT INTO `user_profile` VALUES (19,'chw4571@naver.com','최해온','010-1111-2222','https://d2ud6j7vlf3xy9.cloudfront.net/static/20212718212731-다운로드 1.jpeg','1842510887','1997-10-21T15:00:00.000Z'),(21,'clleo97@naver.com','영주','010-1234-1212','http://k.kakaocdn.net/dn/KAvA7/btq9R4lJj4c/KAfBoQxKphmNxwEsKHK28k/img_640x640.jpg','1842455905',NULL),(22,'geeaee1@nate.com','조다운','010-1111-2222','https://d2ud6j7vlf3xy9.cloudfront.net/static/20210118180138-1d87f4af877b9d55597ec3da983265','1842379765','1997-03-13T15:00:00.000Z'),(24,'ssafy@ssafy.com','ㅎㅅㅎ','0000','http://k.kakaocdn.net/dn/n1Q1R/btrbtyMQhm8/dpyLKhWD42uZFYND7IKIAk/img_640x640.jpg','1842634691','1988-10-15T15:00:00.000Z'),(26,'zxd9857@gmail.com','김구릉','0624','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg','1844412277',NULL),(27,'zxd98@daum.net','이상현','0624','http://k.kakaocdn.net/dn/Gjsby/btrbgkAavdY/6GGhDjgpTma8IJzU9Bugt1/img_640x640.jpg','1842456115','2021-06-15T15:00:00.000Z'),(28,'sqk8657@naver.com','권영린','0121','http://k.kakaocdn.net/dn/vf9si/btq6n6tavJ6/qrT5zKjc2kdkxZ4Jom3c71/img_640x640.jpg','1850646517',NULL),(29,'clleo0403@gmail.com','김미미','010-1234-5678','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg','1853181931',NULL),(30,'doglivetest@kakao.com','도구리부','010-9334-4135','https://d2ud6j7vlf3xy9.cloudfront.net/static/20211220001254-image (5).png','1855869078','Wed Aug 18 2021 00:00:00 GMT+0900 (한국 표준시)'),(31,'livulivu@kakao.com','리부리부','0202','https://d2ud6j7vlf3xy9.cloudfront.net/static/20210920000904-강쥐.jpeg','1855966971','null'),(35,'qlfflwls2@naver.com','나승호','01066064542','https://d2ud6j7vlf3xy9.cloudfront.net/static/20211919151928-KakaoTalk_20210819_013508263.j','1856376811','Tue May 28 1996 00:00:00 GMT+0900 (한국 표준시)'),(36,'hyywon97@kakao.com','몽미',' ','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg','1856130995',NULL),(40,'','네이버',' ','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg','1857336780',NULL),(41,'skdud3384@naver.com','박나영',' ','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg','1857553178',NULL);
/*!40000 ALTER TABLE `user_profile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20 11:01:32
