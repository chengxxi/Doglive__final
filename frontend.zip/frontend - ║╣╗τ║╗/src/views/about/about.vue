<template>
</template>

<style scoped>
</style>

<script>
export default {
  name: 'about',
  setup () {

  }
}
</script>
