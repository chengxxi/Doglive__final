<template>
</template>

<style scoped>
</style>

<script>
export default {
  name: 'about-team',
  setup () {

  }
}
</script>
