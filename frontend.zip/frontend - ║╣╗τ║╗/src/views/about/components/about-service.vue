<template>
</template>

<style scoped>
</style>

<script>
export default {
  name: 'about-service',
  setup () {

  }
}
</script>
