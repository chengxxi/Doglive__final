<template>
</template>

<style scoped>
</style>

<script>
export default {
  name: 'user-post-list',
  setup() {

  }
}
</script>
