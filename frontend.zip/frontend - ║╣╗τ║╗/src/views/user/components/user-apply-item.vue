<template>
</template>

<style scoped>
</style>

<script>
export default {
  name: 'user-apply-item',
  setup () {

  }
}
</script>
