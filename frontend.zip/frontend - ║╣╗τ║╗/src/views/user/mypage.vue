<template>
</template>

<style scoped>
</style>

<script>
export default {
  name: 'mypage',
  setup() {

  }
}
</script>
