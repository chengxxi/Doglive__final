<template>
</template>

<style scoped>
</style>

<script>
export default {
  name: 'login-dialog',
  setup() {

  }
}
</script>
