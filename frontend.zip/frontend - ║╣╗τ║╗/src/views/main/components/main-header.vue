<template>
<h1>Header</h1>
</template>

<style scoped>
</style>

<script>
export default {
  name: 'main-header',
  setup() {

  }
}
</script>
