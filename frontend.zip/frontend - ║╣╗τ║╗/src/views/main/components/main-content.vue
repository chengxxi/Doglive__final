<template>
</template>

<style scoped>
</style>

<script>
export default {
  name: 'main-content',
  setup() {

  }
}
</script>
